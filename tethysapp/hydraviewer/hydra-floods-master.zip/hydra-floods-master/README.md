# hydra-floods

## Introduction
HYDrologic Remote sensing Analysis for Floods (HydraFloods) is a Python application for downloading, processing, and delivering flood maps derived from remote sensing data.
The bases behind the tool is to use as many remote sesnsing dataset as possible to provide daily (sometime twice daily) flood maps.

## Getting started
Coming soon...

## How-to
Coming soon...
